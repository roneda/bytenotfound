﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.BindingHelpers;
using System.Collections.Generic;
using MvcApplication.Models;

namespace MvcApplication.Controllers
{
    public class FeedsController : Controller
    {
        FeedRepository feedRep = new FeedRepository();
        
        [ControllerAction]
        public void List()
        {
            List<Feed> feeds = feedRep.GetAllFeeds();
            RenderView("FeedList", feeds);
        }

        [ControllerAction]
        public void Create()
        {
            Feed feed = new Feed();

            feed.UpdateFrom(Request.Form);
            
            feedRep.AddFeed(feed);
            RedirectToAction("List");
        }

        [ControllerAction]
        public void Delete(int id)
        {
            feedRep.DeleteFeed(id);
            RedirectToAction("List");
        }

        [ControllerAction]
        public void New()
        {
            RenderView("NewFeed");
        }
    }
}
