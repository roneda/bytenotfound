﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using MvcApplication.Models;

namespace MvcApplication.Controllers
{
    public class PostsController : Controller
    {
        [ControllerAction]
        public void List(int id)
        {
            FeedRepository feedRep = new FeedRepository();

            List<Post> posts = feedRep.GetAllPosts(id);
            RenderView("PostList", posts);
        }
    }
}
