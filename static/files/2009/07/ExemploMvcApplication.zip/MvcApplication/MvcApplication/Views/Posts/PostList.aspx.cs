﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using MvcApplication.Models;

namespace MvcApplication.Views.Posts
{
    public partial class PostList : ViewPage<List<Post>>
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.PostRepeater.DataSource = ViewData;
            this.PostRepeater.DataBind();
        }
    }
}
