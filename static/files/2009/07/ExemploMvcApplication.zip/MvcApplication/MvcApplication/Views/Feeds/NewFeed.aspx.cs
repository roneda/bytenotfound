﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication.Views.Feeds
{
    public partial class NewFeed : ViewPage
    {
    }
}
