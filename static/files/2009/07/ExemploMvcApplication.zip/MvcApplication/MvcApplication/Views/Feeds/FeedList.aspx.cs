﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using MvcApplication.Models;

namespace MvcApplication.Views.Feeds
{
    public partial class FeedList : ViewPage<List<Feed>>
    {
    }
}
