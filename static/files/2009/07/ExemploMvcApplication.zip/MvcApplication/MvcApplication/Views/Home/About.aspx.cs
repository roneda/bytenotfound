﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication.Views.Home
{
    public partial class About : ViewPage
    {
    }
}
