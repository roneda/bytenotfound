﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;

namespace MvcApplication.Models
{
    public class FeedRepository
    {
        private string path = HttpContext.Current.Server.MapPath(@"~/App_Data/Feeds.xml");
        private XDocument feedDoc;

        public FeedRepository()
        {
            feedDoc = XDocument.Load(path);
        }

        public void AddFeed(Feed feed)
        {
            XElement newFeed = new XElement("feed",
                new XElement("id", this.GetNextFeedId()),
                new XElement("name", feed.Name),
                new XElement("url", feed.Url));

            feedDoc.Root.Add(newFeed);
            feedDoc.Save(path);
        }

        public void DeleteFeed(int feedId)
        {
            XElement feed = (from f in feedDoc.Descendants("feed")
                            where Int32.Parse(f.Element("id").Value) == feedId
                            select f).Single();

            feed.Remove();
            feedDoc.Save(path);
        }

        public List<Feed> GetAllFeeds()
        {
            var feeds = from feed in feedDoc.Descendants("feed")
                        orderby feed.Element("name").Value
                        select new Feed
                        {
                            Id = Int32.Parse(feed.Element("id").Value),
                            Name = feed.Element("name").Value,
                            Url = feed.Element("url").Value
                        };

            return feeds.ToList();
        }
        
        public List<Post> GetAllPosts(int feedId)
        {
            Feed feed = this.GetFeed(feedId);

            XDocument postDoc = XDocument.Load(feed.Url);

            var posts = from post in postDoc.Descendants("item")
                        orderby DateTime.Parse(post.Element("pubDate").Value) descending 
                        select new Post
                        {
                            Title = post.Element("title").Value,
                            Link = post.Element("link").Value,
                            Date = DateTime.Parse(post.Element("pubDate").Value)
                        };

            return posts.ToList();
        }

        public Feed GetFeed(int feedId)
        {
            var feed =  (from f in feedDoc.Descendants("feed")
                            where Int32.Parse(f.Element("id").Value) == feedId
                            select new Feed
                            {
                               Id = Int32.Parse(f.Element("id").Value),
                               Name = f.Element("name").Value,
                               Url = f.Element("url").Value
                            }).Single();

            return feed;
        }

        public int GetNextFeedId()
        {
            int nextFeedId = (from feed in feedDoc.Descendants("feed")
                             orderby Int32.Parse(feed.Element("id").Value) descending
                             select Int32.Parse(feed.Element("id").Value)).First();

            return nextFeedId + 1;
        }
    }
}
